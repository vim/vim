Updated Vim icons were provided by Pat Suwalski <pat.suwalski@gmail.com> 
(https://groups.google.com/g/vim_dev/c/g-sV7iAVgVE/m/_XMUpPumUpsJ) on 
13 February 2015.

Reworked on 30 September 2025 by RestorerZ <restorer@mail2k.ru> 
(https://github.com/vim/vim/pull/18456).
